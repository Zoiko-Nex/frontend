"use client";

import React from "react";
import { RolesManager } from "../../components/access-control/RolesManager";
import { ToastProvider } from "../../components/access-control/ui";
import { useAccessControlClient } from "@/lib/access-control/useClient";

export function RolesPage() {
  const client = useAccessControlClient();
  return (
    <ToastProvider>
      <div className="mx-auto max-w-4xl px-4 py-8">
        <RolesManager client={client} />
      </div>
    </ToastProvider>
  );
}

export default RolesPage;
